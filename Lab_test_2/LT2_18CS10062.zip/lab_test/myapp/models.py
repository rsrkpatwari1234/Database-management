from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.urls import reverse # Used to generate URLs by reversing the URL patterns
from django.core.validators import RegexValidator

# Table definitions 

class Book(models.Model):
    isbn = models.AutoField(db_column='isbn', primary_key=True, max_length=13)
    author = models.CharField(db_column='author', max_length=256, null=True)
    subject = models.CharField(db_column='subject', max_length=50, blank=True)
    title = models.CharField(db_column='title', max_length=256)
    edition = models.IntegerField(db_column='edition', blank=True, null=True)
    grade = models.IntegerField(db_column='grade', blank=True,null=True,validators=[MinValueValidator(1), MaxValueValidator(12)])
    is_available = models.BooleanField(db_column='is_available', default = True)

    def __str__(self):
        return self.isbn

class User(models.Model):
    user_id = models.AutoField(db_column='user_id', primary_key=True)  
    first_name = models.TextField(db_column='first_name', max_length=10)
    middle_name = models.TextField(db_column='middle_name', max_length=10, blank=True, null=True)
    last_name = models.TextField(db_column='last_name', max_length=10, blank=True, null=True)
    email_address = models.EmailField(db_column='email_address', max_length=40)  
    house_number = models.CharField(db_column='house_number', max_length=10, blank=True, null=True) 
    street_number = models.CharField(db_column='street_number', max_length=10, blank=True, null=True)  
    street_name = models.TextField(db_column='street_name', max_length=50)   
    city = models.TextField(db_column='city', max_length=50)  
    state = models.TextField(db_column='state', max_length=50)  
    postal_code = models.DecimalField(db_column='postal_code', max_digits=6, decimal_places=0) 
    password = models.CharField(db_column='password', max_length=256) 

    def __str__(self):
        """String for representing the Model object."""
        return self.email_address

class Issued(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, db_column='user_id')
    isbn = models.ForeignKey(Book, on_delete=models.CASCADE, db_column='isbn')
    issue_date = models.DateField(db_column='issue_date')
    due_date = models.DateField(db_column='due_date')
    return_date = models.DateField(db_column='return_date',null=True)
    fine = models.IntegerField(db_column='fine', default = 0)

class PhoneNumber(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.DO_NOTHING, db_column='user_id')
    phone_number = models.IntegerField(db_column='phone_number', primary_key=True)

    class Meta:
        unique_together = (('user_id', 'phone_number'),)

class Manager(models.Model):
    manager_id = models.AutoField(db_column='manager_id', primary_key=True)
    first_name = models.TextField(db_column='first_name', max_length=10)
    middle_name = models.TextField(db_column='middle_name', max_length=10, blank=True, null=True)
    last_name = models.TextField(db_column='last_name', max_length=10, blank=True, null=True)
    email_address = models.EmailField(db_column='email_address', max_length=40)
    phone_number = models.IntegerField(db_column='phone_number')
    password = models.CharField(db_column='password', max_length=256)

    def __str__(self):
        """String for representing the Model object."""
        return self.email_address