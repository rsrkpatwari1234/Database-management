from django.urls import path, re_path
from . import views

# using the given urls to direct pages in the application

urlpatterns = [
    path('', views.logIn_user, name='logIn_user'),
    path('signUp/', views.signUp, name='signUp'),
    path('logInUser/', views.logIn_user, name='logIn_user'),
    path('transaction/<int:user_id>/', views.transaction, name='transaction'),
    path('issue_book/<int:user_id>/<str:isbn>/', views.issue_book, name='issue_book'),
    path('return_book/<int:user_id>/<str:isbn>/', views.return_book, name='return_book'),
    path('logInSupervised/', views.logIn_manager, name='logIn_manager'),
    re_path(r'^manage/(?P<message>[a-zA-Z.! ]+)/$', views.manage,name='manage'),
    path('add_book/', views.add_book, name='add_book'),
    path('remove_book/<str:isbn>/', views.remove_book, name='remove_book'),
    path('update_book/<str:isbn>/', views.update_book, name='update_book'),
    path('signOut/', views.signOut, name='signOut'),
]
