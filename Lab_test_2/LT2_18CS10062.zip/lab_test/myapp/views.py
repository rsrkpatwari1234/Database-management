from django.shortcuts import render, redirect

from django.http import HttpResponse
from myapp.models import *

from django.contrib import messages
from django.db import connection

from datetime import date, timedelta

from django.urls import reverse

import json

# inserting using raw sql of django
def insert_using_raw_sql(sql):
    print('sql - ', sql)
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
        return True
    except Exception as e:
        print(e)
        return False

# updating using raw sql of django
def update_using_raw_sql(sql):
    print('sql - ', sql)
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
        return True
    except Exception as e:
        print(e)
        return False

# select using raw sql of django
def select_using_raw_sql(sql):
    print('sql - ', sql)
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
    except Exception as e:
        print(e)
        return []
    results = cursor.fetchall()
    ##print(results)
    l = []
    for  i in range(len(results)):
        dict = {}
        field = 0
        while True:
            try:
                dict[cursor.description[field][0]] = str(results[i][field])
                field = field +1
            except IndexError as e:
                break
        l.append(dict)
    return l

# deleting using raw sql of django
def delete_using_raw_sql(sql):
    print('sql - ', sql)
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
        return True
    except Exception as e:
        print(e)
        return False

# alredy signed up user log in into the system
def logIn_user(request):

    if request.method == "POST":
        email = request.POST.get("email")
        results = select_using_raw_sql("SELECT du.user_id,du.password FROM myapp_user AS du WHERE du.email_address='" + str(email) + "'")
        
        if results:
            for user in results:
                if user['password'] == request.POST.get("password"):
                    #return render(request, 'user_ui.html', {'current_user':user['user_id']})
                    return redirect(reverse('transaction', kwargs={"user_id": user['user_id']}))
        else:
            messages.error(request, 'Email id or password does not match!')
            
    return render(request, 'logInUser.html')

# new user tries to sign up
def signUp(request):

    if request.method == "POST":
        results = select_using_raw_sql("SELECT * FROM myapp_user")
        for user in results:
            if user['email_address'] == request.POST.get("email"):
                messages.error(request, 'This email address has been taken!')
                return render(request, 'SignUp.html') 

        if request.POST.get("password") != request.POST.get("repeat_password"):
            messages.error(request, 'Password does not match!')
            return render(request, 'SignUp.html')


        FirstName = request.POST.get("first_name")
        MiddleName = request.POST.get("middle_name")
        LastName = request.POST.get("last_name")
        Email = request.POST.get("email")
        HouseNo = request.POST.get("house_no")
        StreetNo = request.POST.get("street_no")
        StreetName = request.POST.get("street_name")
        City = request.POST.get("city")
        State = request.POST.get("state")
        PostalCode = request.POST.get("zipcode")
        Password = request.POST.get("password")

        i = "myapp_user(postal_code,first_name,middle_name,last_name,email_address,house_number,street_number,street_name,city,state,password)"
        j = "values("+str(PostalCode)+",'"+str(FirstName)+"','"+str(MiddleName)+"','"+str(LastName)+"','"+str(Email)+"','"+str(HouseNo)+"','"+str(StreetNo)+"','"+str(StreetName)+"','"+str(City)+"','"+str(State)+"','"+str(Password)+"')"
        

        command = "INSERT INTO " + i +" "+ j
        if insert_using_raw_sql(command):
            result = select_using_raw_sql("SELECT du.user_id FROM myapp_user AS du WHERE du.email_address='"+str(Email)+"'")
            print(json.dumps(results,indent=4))
            result = insert_using_raw_sql("INSERT INTO myapp_phonenumber(user_id, phone_number) VALUES("+str(result[0]['user_id'])+","+str(request.POST.get("phone_no"))+")")
            print(json.dumps(results,indent=4))
            messages.success(request, 'Your account has been created successfully!')
            return redirect('/myapp/logInUser/')
        else:
            messages.error(request, 'Internal error! Try again.') 
            return redirect('/myapp/signUp/')

        # user = User.objects.create(user_id=UserId, email_address=Email, first_name=FirstName, middle_name=MiddleName,
        #                            last_name=LastName, house_number=HouseNo, street_number=StreetNo, street_name=StreetName, 
        #                            city=City, state=State, postal_code=PostalCode, password=Password)
        # messages.success(request, 'Your account has been created successfully!')
        # return render(request, 'logInUser.html')

    else:
        return render(request, 'SignUp.html')


# user or manager tries to sign out of the application
def signOut(request):
    return redirect('/myapp/logInUser/')


# log in facility for the manager of the application
def logIn_manager(request):
    if request.method == "POST":
        email = request.POST.get("email")
        results = select_using_raw_sql("SELECT dm.manager_id,dm.password FROM myapp_manager AS dm WHERE dm.email_address='" + str(email) + "'")
        
        if results:
            for user in results:
                if user['password'] == request.POST.get("password"):
                    message = "Successfully logged In"
                    return redirect(reverse('manage', kwargs={"message":message}))
        else:
            messages.error(request, 'Email id or password does not match!')
            
    return render(request, 'logInManager.html')


# transaction details and features available to the user of the application
def transaction(request, user_id):

    user_name = select_using_raw_sql("SELECT UPPER(first_name) FROM myapp_user as du WHERE du.user_id =" + str(user_id))
    #print(json.dumps(user_name,indent=4))

    issued_books = select_using_raw_sql("SELECT db.isbn as isbn, UPPER(db.title) as title,UPPER(db.author) as author,di.issue_date as issue_date,di.return_date as return_date,di.due_date as due_date,di.fine as fine\
            FROM myapp_book AS db, myapp_issued AS di\
            WHERE  db.isbn=di.isbn AND di.user_id='"+str(user_id)+"'")

    total_issued = select_using_raw_sql("SELECT COUNT(DISTINCT(isbn)) \
        FROM myapp_issued AS di\
        WHERE di.user_id ="+str(user_id)+" AND di.return_date IS NULL")

    available_books = select_using_raw_sql("SELECT db.isbn as isbn, UPPER(db.title) as title,UPPER(db.author) as author,db.subject as subject,db.grade as grade,db.edition as edition \
            FROM myapp_book AS db\
            WHERE  db.is_available=1")

    print(json.dumps(available_books,indent=4))
    print(json.dumps(issued_books,indent=4))

    if total_issued[0]['COUNT(DISTINCT(isbn))'] < '5':
        allow = 'True'
    else:
        allow = 'False'

    data = {
            'user_id':user_id,
            'allow':allow,
            'user_name':user_name[0]['UPPER(first_name)'],
            'issued_books':issued_books,
            'available_books':available_books,
        }   
    return render(request, 'user_ui.html', data)


# Overall transactions and facilities available to the manager
def manage(request, message):

    user_details = select_using_raw_sql("SELECT du.user_id AS user_id,du.first_name||' '||du.middle_name||' '||du.last_name AS name,du.email_address AS  email,\
        du.house_number AS house_number,du.street_number AS street_number,du.street_name AS street_name,UPPER(du.city) AS city,UPPER(du.state) AS state,du.postal_code AS postal_code\
        FROM myapp_user AS du")
    issued_books = select_using_raw_sql("SELECT db.isbn as isbn, UPPER(db.title) as title,UPPER(db.author) as author,di.user_id as user_id,di.issue_date as issue_date\
            FROM myapp_book AS db, myapp_issued AS di\
            WHERE  db.is_available<>1 AND di.isbn=db.isbn")
    available_books = select_using_raw_sql("SELECT db.isbn as isbn, UPPER(db.title) as title,UPPER(db.author) as author,db.subject as subject,db.grade as grade,db.edition as edition \
            FROM myapp_book AS db\
            WHERE  db.is_available=1")

    data = {
            'message':message,
            'user_details':user_details,
            'issued_books':issued_books,
            'available_books':available_books,
        }
    return render(request, 'manager_ui.html', data)

# Admin can add a book to the library
def add_book(request):

    if request.method == "POST":

        Author = request.POST.get("author")
        Subject = request.POST.get("subject")
        Title = request.POST.get("title")
        Edition = request.POST.get("edition")
        Grade = request.POST.get("class")

        i = "myapp_book(author, subject, title, edition, grade, is_available)"
        j = "values('"+str(Author)+"','"+str(Subject)+"','"+str(Title)+"',"+str(Edition)+","+str(Grade)+",1)"
        
        command = "INSERT INTO " + i +" "+ j

        if insert_using_raw_sql(command):
            results = select_using_raw_sql("SELECT * FROM myapp_book")
            print(json.dumps(results,indent=4))

            message = "Successfully Added the book"
            return redirect(reverse('manage', kwargs={"message":message}))
        else:
            messages.error(request, 'Internal error! Try again.')
    return render(request, 'add_book.html')

# Admin can remove a book to the library
def remove_book(request,isbn):  

    command = "DELETE FROM myapp_book WHERE isbn='"+str(isbn)+"'"

    if delete_using_raw_sql(command):
        results = select_using_raw_sql("SELECT * FROM myapp_book")
        print(json.dumps(results,indent=4))
    else:
        message = "Internal error occured. Unable to remove book"
        return redirect(reverse('manage', kwargs={"message":message}))

    message = "Successfully Removed the book"
    return redirect(reverse('manage', kwargs={"message":message}))

# Admin can update a book to the library
def update_book(request,isbn):  

    if request.method == "POST":
        Edition = request.POST.get("edition")
        command = "UPDATE myapp_book SET edition="+str(Edition)+" WHERE isbn='"+str(isbn)+"'"
        if update_using_raw_sql(command):
            message = "Successfully updated edition of the book"
        else:
            message = "Internal error occured. Unable to update book"
    else:
        results = select_using_raw_sql("SELECT db.isbn as isbn, UPPER(db.title) as title,UPPER(db.author) as author,db.grade as grade,db.subject as subject,db.edition as edition\
            FROM myapp_book AS db\
            WHERE  db.isbn='"+str(isbn)+"'")

        data = {
            'isbn':results[0]['isbn'],
            'author':results[0]['author'],
            'title':results[0]['title'],
            'grade':results[0]['grade'],
            'edition':results[0]['edition'],
            'subject':results[0]['subject'],
        }
        return render(request, 'update_book.html',data)

    return redirect(reverse('manage', kwargs={"message":message}))

#  logged in user can issue a  book
def issue_book(request, user_id, isbn):

    issue_date =  date.today()
    due_date = issue_date + timedelta(days=5)

    command1 = "INSERT INTO myapp_issued(isbn, user_id, issue_date, due_date, return_date,fine) \
    values('"+str(isbn)+"',"+str(user_id)+",'"+str(issue_date)+"','"+str(due_date)+"',NULL,0)"

    command2 = "UPDATE myapp_book SET is_available=0 WHERE isbn='"+str(isbn)+"'"

    if insert_using_raw_sql(command1) and update_using_raw_sql(command2):
        results = select_using_raw_sql("SELECT * FROM myapp_issued")
        print(json.dumps(results,indent=4))
        messages.success(request, 'Thank you for issuing book.')
    else:
        messages.error(request, 'Internal error! Try again.')
    return redirect(reverse('transaction', kwargs={"user_id":user_id}))

#  logged in user can issue a  book
def return_book(request, user_id, isbn):

    command1 = "UPDATE myapp_issued SET return_date='"+str(date.today())+"' WHERE isbn='"+str(isbn)+"'" 
    command2 = "UPDATE myapp_book SET is_available=1 WHERE isbn='"+str(isbn)+"'"

    if update_using_raw_sql(command1) and update_using_raw_sql(command2):
        results = select_using_raw_sql("SELECT * FROM myapp_issued")
        print(json.dumps(results,indent=4))
        messages.success(request, 'Thank you for returning book.')
    else:
        messages.error(request, 'Internal error! Try again.')
    return redirect(reverse('transaction', kwargs={"user_id":user_id}))