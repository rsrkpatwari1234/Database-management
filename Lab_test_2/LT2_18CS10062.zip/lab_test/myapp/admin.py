from django.contrib import admin
from myapp.models import *

# tables that will be visible in Admin site

admin.site.register(Book)
admin.site.register(Manager)
admin.site.register(User)
admin.site.register(Issued)
admin.site.register(PhoneNumber)